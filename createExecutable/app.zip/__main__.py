print ("Hello world from Python")
